using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG6212_POE_Part2
{
    /// <summary>
    /// Interaction logic for HRDashboard.xaml
    /// </summary>
    public partial class HRDashboard : Window
    {
        string DBConn = "Data Source=LAPTOP-BBJQNRDV;Initial Catalog=PROG6212_POE;Integrated Security=True;";

        public HRDashboard()
        {
            InitializeComponent();
            LoadApprovedClaims();
            LoadLecturerData();
        }

        private void LoadApprovedClaims()
        {
            List<Claim> approvedClaims = GetApprovedClaimsFromDatabase();
            ApprovedClaimsListView.ItemsSource = approvedClaims;
        }

        private List<Claim> GetApprovedClaimsFromDatabase()
        {
            List<Claim> claims = new List<Claim>();
            string query = "SELECT ClaimClassTaught, ClaimLessonNum, ClaimHourlyRate, ClaimTotalAmount FROM Claims WHERE ClaimStatus = 'Approved'";

            using (SqlConnection connection = new SqlConnection(DBConn))
            {
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        claims.Add(new Claim
                        {
                            ClaimClassTaught = reader.GetString(0),
                            ClaimLessonNum = reader.GetInt32(1),
                            ClaimHourlyRate = reader.GetDecimal(2),
                            ClaimTotalAmount = reader.GetDecimal(3),
                            LecturerName = "Lecturer Name" // Replace with actual lecturer name retrieval logic
                        });
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            return claims;
        }

        private void LoadLecturerData()
        {
            List<Lecturer> lecturers = GetLecturerDataFromDatabase();
            LecturerDataGrid.ItemsSource = lecturers;
        }

        private List<Lecturer> GetLecturerDataFromDatabase()
        {
            List<Lecturer> lecturers = new List<Lecturer>();
            string query = "SELECT LecturerID, LecturerName, LecturerEmail FROM Lecturer";

            using (SqlConnection connection = new SqlConnection(DBConn))
            {
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        lecturers.Add(new Lecturer
                        {
                            LecturerID = reader.GetInt32(0),
                            LecturerName = reader.GetString(1),
                            LecturerEmail = reader.GetString(2)
                        });
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            return lecturers;
        }

        private void GenerateReportButton_Click(object sender, RoutedEventArgs e)
        {
            // Generate a simple report showing total claim amount per lecturer
            Dictionary<string, decimal> lecturerClaimTotals = new Dictionary<string, decimal>();
            foreach (Claim claim in GetApprovedClaimsFromDatabase())
            {
                if (lecturerClaimTotals.ContainsKey(claim.LecturerName))
                {
                    lecturerClaimTotals[claim.LecturerName] += claim.ClaimTotalAmount;
                }
                else
                {
                    lecturerClaimTotals[claim.LecturerName] = claim.ClaimTotalAmount;
                }
            }

            // Display the report in a message box (for demonstration purposes)
            string report = "Lecturer Claim Report:\n";
            foreach (var entry in lecturerClaimTotals)
            {
                report += $"{entry.Key}: R{entry.Value}\n";
            }
            MessageBox.Show(report);
        }

        private void ManageLecturersButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Manage Lecturers functionality will be implemented here.");
        }
    }


    public partial class Lecturer
    {
        public int LecturerID { get; set; }
        public string LecturerName { get; set; }
        public string LecturerEmail { get; set; }
    }
}
