namespace PROG6212_POE_Part2
{
    public class Claim
    {
        public int ClaimID { get; set; }
        public string ClaimClassTaught { get; set; }
        public int ClaimLessonNum { get; set; }
        public decimal ClaimHourlyRate { get; set; }
        public decimal ClaimTotalAmount { get; set; }
        public string ClaimStatus { get; set; }

        public string VerificationStatus { get; set; }

        public string LecturerName { get; set; }
    }
}