﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG6212_POE_Part2
{
    /// <summary>
    /// 
    /// </summary>
    public partial class SubmitClaim : Window
    {
        public SubmitClaim()
        {
            InitializeComponent();
        }

        string DBConn = "Data Source=LAPTOP-BBJQNRDV;Initial Catalog=PROG6212_POE;Integrated Security=True;";

        private List<string> uploadedFileNames = new List<string>();


        private void btnSupDoc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Multiselect = true,
                    Title = "Select Documents",
                    Filter = "PDF Files (*.pdf)|*.pdf|Word Documents (*.docx;*.doc)|*.docx;*.doc|Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    txtSupDoc.Text = string.Join(", ", uploadedFileNames);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();

        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtLessonNum.Text) || string.IsNullOrEmpty(txtHourlyRate.Text))
            {
                MessageBox.Show("Please enter Lesson Number and Hourly Rate");
                return;
            }

            if (!int.TryParse(txtLessonNum.Text, out int lessonNum) || !decimal.TryParse(txtHourlyRate.Text, out decimal hourlyRate))
            {
                MessageBox.Show("Please enter valid numeric values for Lesson Number and Hourly Rate.");
                return;
            }

            decimal TotalAmount = lessonNum * hourlyRate;
            txtTotalClaimAmount.Text = $"R{TotalAmount}";
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string ClaimClassTaught = txtClassTaughtNum.Text;
            string ClaimLessonNum = txtLessonNum.Text;
            string ClaimHourlyRate = txtHourlyRate.Text;
            string ClaimTotalAmount = txtTotalClaimAmount.Text;
            string ClaimSupDocs = txtSupDoc.Text;
            string ClaimStatus = "Pending";

            if (string.IsNullOrEmpty(ClaimTotalAmount))
            {
                MessageBox.Show("Please calculate the total claim amount.");
                return;
            }

            SubmitClaimToDatabase(ClaimClassTaught, ClaimLessonNum, ClaimHourlyRate, ClaimTotalAmount, ClaimSupDocs, ClaimStatus);
        }

        private void SubmitClaimToDatabase(string ClaimClassTaught, string ClaimLessonNum, string ClaimHourlyRate, string ClaimTotalAmount, string ClaimSupDocs, string ClaimStatus)
        {
            if (!VerifyDatabaseConnection())
            {
                MessageBox.Show("Unable to connect to the database. Please check your connection settings.");
                return;
            }

            string query = "INSERT INTO Claims (ClaimClassTaught, ClaimLessonNum, ClaimHourlyRate, ClaimTotalAmount, ClaimSupDocs, ClaimStatus) VALUES (@ClaimClassTaught, @ClaimLessonNum, @ClaimHourlyRate, @ClaimTotalAmount, @ClaimSupDocs, @ClaimStatus)";

            using (SqlConnection conn = new SqlConnection(DBConn))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClaimClassTaught", ClaimClassTaught);
                cmd.Parameters.AddWithValue("@ClaimLessonNum", ClaimLessonNum);
                cmd.Parameters.AddWithValue("@ClaimHourlyRate", ClaimHourlyRate);
                cmd.Parameters.AddWithValue("@ClaimTotalAmount", ClaimTotalAmount);
                cmd.Parameters.AddWithValue("@ClaimSupDocs", ClaimSupDocs);
                cmd.Parameters.AddWithValue("@ClaimStatus", ClaimStatus);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Claim submitted successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred while submitting the claim: {ex.Message}\n{ex.StackTrace}");
                }
            }
        }

        private bool VerifyDatabaseConnection()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConn))
                {
                    conn.Open(); // Try to open the connection
                    return true; // Connection is successful
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"Connection error: {sqlEx.Message}");
                return false; // Connection failed
            }
        }

    }
}
